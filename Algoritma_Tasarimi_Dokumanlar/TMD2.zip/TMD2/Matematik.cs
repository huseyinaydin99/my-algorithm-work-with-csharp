﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TMD2
{
    public class Matematik
    {
        /// <summary>
        /// Parameter olarak aldigi taban ve kuvvet bagli olarak ustAlma islemini gerceklestirir.
        /// </summary>
        /// <param name="taban">Taban</param>
        /// <param name="kuvvet">Kuvet</param>
        /// <returns>Sonuc</returns>
        public static double UstAlma(double taban, double kuvvet)
        {
            double s = 1;
            for (int i = 1; i <= kuvvet; i++)
                s *= taban;
            return s;
        }

        /// <summary>
        /// İki sayının en küçük ortak katını bulur. 
        /// </summary>
        /// <param name="s1">1.Sayi</param>
        /// <param name="s2">2.Sayi</param>
        /// <returns>OKEK değerini döner.</returns>
        public static int OKEK(int s1, int s2)
        {
            int s = 1;
            int bol = 2;
            while (s1!=1 && s2!=1)
            {
                for (int i = 1; i <= (s1>s2 ? s1 : s2); i++)
                {
                    if (s1 % bol == 0 || s2 % bol == 0)
                    {
                        s *= bol;
                        if (s1 % bol == 0)
                            s1 /= bol;
                        if (s2 % bol == 0)
                            s2 /= bol;
                    }
                    else
                        bol++;
                }
            }
            return s;
        }

        /// <summary>
        /// İki sayının en büyük ortak bölenini bulur.
        /// </summary>
        /// <param name="s1">1. Sayı</param>
        /// <param name="s2">2. Sayı</param>
        /// <returns>OBEB değerini döner</returns>
        public static int OBEB(int s1, int s2)
        {
            int s = 1;
            int bolen = 2;
            while (s1!=1 && s2!=1)
            {
                for (int i = 2; i < (s1>s2 ? s1 : s2); i++)
                {
                    if (s1 % bolen == 0 || s2 % bolen == 0)
                    {
                        if (s1 % bolen == 0 && s2 % bolen == 0)
                            s *= bolen;
                        if (s1 % bolen == 0)
                            s1 /= bolen;
                        if (s2 % bolen == 0)
                            s2 /= bolen;
                    }
                    else
                        bolen++;
                }
            }
            return s;
        }

        /// <summary>
        /// Bir sayinin asal carpanlarini verir. 
        /// </summary>
        /// <param name="n"> Sayiyi temsil eder. </param>
        /// <returns>Asal carpanlar dizisidir.</returns>
        public static int[] AsalCarpanlar(int n)
        {
            string carpanListesi = "";
            int i = 2;

            // asal carpanlari bulalım
            while (n>1)
            {
                if (n % i == 0)
                {
                    n = n / i;
                    carpanListesi += i.ToString() + ",";
                }
                else
                    i++;
            }

            carpanListesi = carpanListesi.Substring(0, carpanListesi.Length - 1);
            string[] carpanlar = carpanListesi.Split(",");

            string s = carpanlar[0];
            string y = s;

            for (i = 0; i < carpanlar.Length; i++)
            {
                if (!(s==carpanlar[i]))
                {
                    y = y + "," + carpanlar[i];
                    s = carpanlar[i];
                }
            }

            carpanlar = y.Split(',');
            int[] asalCarpanlar = new int[carpanlar.Length];
            for (i = 0; i < asalCarpanlar.Length; i++)
                asalCarpanlar[i] = Convert.ToInt32(carpanlar[i]);
            return asalCarpanlar;
        }

        /// <summary>
        /// Bir sayinin asal carpanlarinin toplamini verir.
        /// </summary>
        /// <param name="n">Sayi</param>
        /// <returns>Toplam</returns>
        public static int AsalCarpanlarinToplami(int n)
        {
            int[] asalCarpanlar = AsalCarpanlar(60);
            int t = 0;
            for (int i = 0; i < asalCarpanlar.Length; i++)
                t += asalCarpanlar[i];
            return t;
        }

        /// <summary>
        /// Bir sayinin asal carpanlarinin carpimini hesaplar.
        /// </summary>
        /// <param name="n">Sayi</param>
        /// <returns>Carpim sonucu</returns>
        public static int AsalCarpanlarinCarpimi(int n)
        {
            int c = 1;
            int[] asalCarpanlar = AsalCarpanlar(n);
            for (int i = 0; i < asalCarpanlar.Length; i++)
                c *= asalCarpanlar[i];
            return c;
        }
       
        /// <summary>
        /// Faktoriyel hesabi yapar.
        /// </summary>
        /// <param name="n">Faktoriyeli hesaplanacak sayiyi temsil eder.</param>
        /// <returns>Sonuc ifadesidir.</returns>
        public static int Faktoriyel(int n)
        {
            if (n <= 1)
                return 1;
            int f = 1;
            for (int i = 2; i <= n; i++)
                f *= i;
            return f;
        }

        public static int İkilikTabandan10lukTabanaGec(string ikilikSayi)
        {
            // uzunlugu belirle
            int n = ikilikSayi.Length;

            // her bir basamagin dizide tutulmasi
            int[] basamaklar = new int[n];

            // onluk karsiligi
            int sayi = 0;
            bool kontrol = true;
            for (int i = 0; i < n; i++)
            {
                if (!(ikilikSayi[i] == '0' || ikilikSayi[i] == '1'))
                {
                    Console.WriteLine("\aHatali Giris!");
                    kontrol = false;
                    break;
                }
                basamaklar[i] = (ikilikSayi[i] - '0');
            }

            // 2'lik sistemden 10'luk sisteme geçiş
            if (kontrol)
            {
                for (int i = 0; i < n; i++)
                    sayi += (int)Math.Pow(2, n - 1 - i) * basamaklar[i];
                Console.WriteLine("({0}) ikilik sayi = {1}",
                    ikilikSayi, sayi);
            }

            return sayi;
        }
        

    }
}
