﻿using AlgoritmaTasarimi.Temeller.Banka;
using AlgoritmaTasarimi.Temeller.Cizim;
using AlgoritmaTasarimi.Temeller.Genel;
using AlgoritmaTasarimi.Temeller.GenericTip.GenericTipler2;
using AlgoritmaTasarimi.Temeller.Modelleme;
using System;
using System.Collections;
using System.Collections.Generic;
using Temeller = AlgoritmaTasarimi.Temeller;
namespace AlgoritmaTasarimi.Temeller
{
   
    class Program
    {
        public static void SekilCiz(Sekil sekil) 
            => sekil.Ciz();
        
        static void Main(string[] args)
        {
            IBankaHesap mevduatHesabi = new MevduatHesabi();
            ITransfer aktifHesap = new AktifHesap();
            aktifHesap.Yatir(250);
            
            mevduatHesabi.Yatir(500);
            aktifHesap.TransferYap(mevduatHesabi, 200);
            
            Console.WriteLine(aktifHesap.ToString());
            Console.WriteLine(mevduatHesabi.ToString());
        }
    }
}


