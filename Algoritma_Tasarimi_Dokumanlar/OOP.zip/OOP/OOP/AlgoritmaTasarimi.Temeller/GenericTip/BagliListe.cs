﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace AlgoritmaTasarimi.Temeller.GenericTip
{
    public class BagliListe<T> : IEnumerable<T>
    {
        public BagliListeDugumu<T> Ilk { get; private set; }
        public BagliListeDugumu<T> Son { get; private set; }

        public BagliListeDugumu<T> SonaEkle(T node)
        {
            var yeniDugum = new BagliListeDugumu<T>(node);
            if(Ilk==null)
            {
                Ilk = yeniDugum;
                Son = Ilk;
            }
            else
            {
                BagliListeDugumu<T> onceki = Son;
                Son.Ileri = yeniDugum;
                Son = yeniDugum;
                Son.Geri = onceki;
            }
            return yeniDugum;
        }
        public IEnumerator<T> GetEnumerator()
        {
            BagliListeDugumu<T> guncel = Ilk;
            while(guncel!=null)
            {
                yield return guncel.Value;
                guncel = guncel.Ileri;
            }
        }
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
       
    }
}
