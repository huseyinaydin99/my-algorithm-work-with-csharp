﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgoritmaTasarimi.Temeller.GenericTip
{
    public class BagliListeDugumu<T>
    {
        public BagliListeDugumu(T value) => Value = value;
        public T Value { get; }
        public BagliListeDugumu<T> Ileri { get; internal set; }
        public BagliListeDugumu<T> Geri { get; internal set; }

    }
}
