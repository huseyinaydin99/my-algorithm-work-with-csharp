﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgoritmaTasarimi.Temeller.GenericTip.GenericTipler2
{
   public class StaticDemo<T>
    {
        public static int x;
    }
}
