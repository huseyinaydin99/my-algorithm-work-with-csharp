﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgoritmaTasarimi.Temeller.Cizim
{
    public class Dikdortgen : Sekil
    {
        public Dikdortgen() : base()
        {
            Console.WriteLine("Derived class-> contrustors");
        }

        public Dikdortgen(int genislik, int yukseklik, 
            int x, int y) : base(genislik, yukseklik, 
                x, y)
        {
            Console.WriteLine("Derived class-> ctor - 4p");
        }

        public override void Ciz() =>
            Console.Write($"Dikdortgen {Pozisyon} - {Boyut}");

        public override void Tasi(Pozisyon yeniPozisyon)
        {
            Console.WriteLine("");
            Console.Write("Dikdortgen ");
            base.Tasi(yeniPozisyon);
        }

        public override void YenidenBoyutlandir(int genislik, 
            int yukseklik)
        {
            Boyut.Genislik = genislik;
            Boyut.Yukseklik = yukseklik;
        }
    }
}
