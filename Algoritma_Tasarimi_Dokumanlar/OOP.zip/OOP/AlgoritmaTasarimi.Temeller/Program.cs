﻿
using AlgoritmaTasarimi.Temeller.Cizim;
using System;
using System.Collections;
using System.Collections.Generic;
using Temeller = AlgoritmaTasarimi.Temeller;
namespace AlgoritmaTasarimi.Temeller
{
   
    class Program
    {
              
        static void Main(string[] args)
        {
            Sekil s = new Sekil();
            s.Pozisyon.X = 5;
            s.Pozisyon.Y = 10;
            s.Boyut.Genislik = 100;
            s.Boyut.Yukseklik = 50;
            s.Ciz();


            Dikdortgen d = new Dikdortgen();
            d.Pozisyon.X = 15;
            d.Pozisyon.Y = 15;
            d.Boyut.Genislik = 200;
            d.Boyut.Yukseklik = 200;
            d.Ciz(); // Dikdortgen ---

            Elips e = new Elips();
            e.Pozisyon.X = 25;
            e.Pozisyon.Y = 15;
            e.Boyut.Genislik = 100;
            e.Boyut.Yukseklik = 150;
            e.Ciz(); 
        }
    }
}


