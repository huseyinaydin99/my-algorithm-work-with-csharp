﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgoritmaTasarimi.Temeller.Cizim
{
    public class Dikdortgen : Sekil
    {
        public override void Ciz()
        {
            Console.Write("Dikdortgen ");
            base.Ciz();
        }
    }
}
