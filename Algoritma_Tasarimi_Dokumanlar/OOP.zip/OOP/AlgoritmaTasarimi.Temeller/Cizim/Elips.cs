﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgoritmaTasarimi.Temeller.Cizim
{
    public class Elips : Sekil
    {

    }
}
