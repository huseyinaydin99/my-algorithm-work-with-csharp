﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgoritmaTasarimi.Temeller.Cizim
{
    public class Pozisyon
    {
        public int X { get; set; }
        public int Y { get; set; }

        public override string ToString() =>
            $"{X} - {Y}";
        
    }

    public class Boyut
    {
        public int Genislik { get; set; }
        public int Yukseklik { get; set; }

        public override string ToString() =>
            $"{Genislik} - {Yukseklik}";
        
    }
    public class Sekil
    {
        public Sekil()
        {

        }



        public Pozisyon Pozisyon { get; } = new Pozisyon();
        public Boyut Boyut { get; } = new Boyut();

        public virtual void Ciz() =>
            Console.WriteLine($" {Pozisyon} - {Boyut}");

      

        

    }
}
