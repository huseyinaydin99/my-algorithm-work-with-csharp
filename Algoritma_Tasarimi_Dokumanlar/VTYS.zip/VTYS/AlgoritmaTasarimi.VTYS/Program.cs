﻿using AlgoritmaTasarimi.VTYS.Rehber;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace AlgoritmaTasarimi.VTYS
{
    class Program
    {
        /*
         * Rehberim.Listele(10);
           Menu.RehberMenu();
         */
        static void Main(string[] args)
        {
            Rehberim.Sayfalama(5);
        }
    }
}
