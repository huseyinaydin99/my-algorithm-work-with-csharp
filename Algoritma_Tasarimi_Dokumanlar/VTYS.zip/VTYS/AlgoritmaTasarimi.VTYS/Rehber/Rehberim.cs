﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace AlgoritmaTasarimi.VTYS.Rehber
{
    public static class Rehberim 
    {
        public static void Listele() => Listele("artan");
        
        public static void Listele(string s="artan")
        {
            List<KisiIletisim> liste = ListeGetir();
            if(s.Equals("artan"))
            {
                var query = from k in liste
                            orderby k.Adi, k.Soyadi
                            select k;
                Yazdir(query.ToList());
            }
            else
            {
                var query = from k in liste
                            orderby k.Adi descending, k.Soyadi descending
                            select k;
                Yazdir(query.ToList());
            }
        }
        public static void Listele(int kayitSayisi=10)
        {
            var iletisim = Iletisim.Listele();
            var kisi = Kisi.Listele();

            var liste = (from i in iletisim
                         join k in kisi on i.KisiId equals k.Id
                         orderby k.Adi
                         select new
                         {
                             k.Id,
                             k.Adi,
                             k.Soyadi,
                             i.GSM,
                             i.Eposta,
                             i.Adres
                         }).Take(kayitSayisi);

            foreach (var item in liste)
            {
                Console.WriteLine($"{item.Id,-15}" +
                    $"{item.Adi,-15}" +
                    $"{item.Soyadi,-15}" +
                    $"{item.GSM,-15}" +
                    $"{item.Eposta,-30}" +
                    $"{item.Adres,-15}");
            }

            Console.WriteLine($"\n\n{liste.Count()} eleman görüntülendi.");
        }

        private static void Yazdir(List<KisiIletisim> liste)
        {
            Console.WriteLine("{0,-15}\t" +
                     "{1,-15}\t\t" +
                     "{2,-15}\t\t" +
                     "{3,-15}","Id","Adi","Soyadi","GSM");

            foreach (var k in liste)
            {
                
                Console.WriteLine($"{k.Id,-15}\t" +
                    $"{k.Adi,-15}\t\t" +
                    $"{k.Soyadi,-15}\t\t" +
                    $"{k.GSM,-15}");
            }
        }
      
        public static List<KisiIletisim> ListeGetir()
        {
            List<KisiIletisim> liste = new List<KisiIletisim>();
            SqlCommand cmd = new SqlCommand("SELECT * FROM vw_KisiIletisim");
            SqlDataReader reader = VTYS.SqlExecuteReader(cmd);
            while (reader.Read())
            {
                liste.Add(new KisiIletisim(
                    Convert.ToInt32(reader[0]),
                    reader[1].ToString().Trim(),
                    reader[2].ToString().Trim(),
                    Convert.ToInt32(reader[3]),
                    reader[4].ToString().Trim(),
                    reader[5].ToString().Trim(),
                    reader[6].ToString().Trim()
                    ));
            }
            return liste;
        }

        public static void Ara(string ifade)
        {
            List<KisiIletisim> liste = ListeGetir();

            var query = from k in liste
                        where k.Adi.Contains(ifade) ||
                                k.Soyadi.Contains(ifade) ||
                                k.GSM.Contains(ifade) ||
                                k.Id.ToString().Contains(ifade)
                        select k;
            Yazdir(query.ToList());             
        }

        public static void KatologYazdir()
        {
            var liste = Rehberim.ListeGetir();

            var query = from k in liste
                        orderby k.Adi, k.Soyadi
                        group k by k.Adi[0];

            foreach (var item in query)
            {
                Console.WriteLine("\n{0} {1} {0}",
                    new string('-', 40),
                    item.Key);
                foreach (var kisi in item)
                {
                    Console.WriteLine($"{kisi.Id,-15} " +
                        $"{kisi.Adi,-15} " +
                        $"{kisi.Soyadi,-15} " +
                        $"{kisi.GSM,-15} " +
                        $"{kisi.Adres,-15}");
                }
            }
        }

        public static void IllereGoreKayitlar()
        {
            var liste = Rehberim.ListeGetir();

            var query = liste.OrderBy(k => k.Adres)
                .GroupBy(k => k.Adres)
                .Select(l => new { Adres = l.Key, Sayi = l.Count() });

            foreach (var item in query)
            {
                Console.WriteLine("{0,-10} -> ({1})",
                    item.Adres,
                    item.Sayi);
            }
        }

        public static void IllereGoreKayitlarIsimListeli()
        {
            var liste = Rehberim.ListeGetir();
            var query = from k in liste
                        orderby k.Adres
                        group k by k.Adres into iller
                        select iller;

            foreach (var item in query)
            {
                Console.WriteLine("{0} \t {1,-10} {0}",
                    new string('-', 15),
                    item.Key.ToUpper());
                foreach (var k in item)
                    Console.WriteLine("{0,-15} {1,-15} {2,-15}",
                        k.Adi, k.Soyadi, k.GSM);
                Console.WriteLine("");
            }
        }

        public static void Sayfalama(int sayfaBoyutu = 10)
        {
            var liste = Rehberim.ListeGetir();
            var sonuc = from k in liste
                        orderby k.Adi
                        select k;
            
            int sayfaNumarasi = (int)
                Math.Ceiling(sonuc.Count() /
                (double)sayfaBoyutu);

            for (int sayfa = 0; sayfa < sayfaNumarasi; sayfa++)
            {
                Console.WriteLine("\n\n{0} Sayfa {1}/{2} {0}\n\n",
                    new string(' ', 50),
                    sayfa + 1,
                    sayfaNumarasi);

                var kayitlar = (from k in sonuc
                                select k).Skip(sayfa * sayfaBoyutu)
                               .Take(sayfaBoyutu);

                foreach (var item in kayitlar)
                {
                    Console.WriteLine($"{item.Id,-15}" +
                        $"{item.Adi,-15}" +
                        $"{item.Soyadi,-15}" +
                        $"{item.GSM,-15}" +
                        $"{item.Eposta,-30}" +
                        $"{item.Adres,-15}\n");
                }
                Console.ReadKey();
                Console.Clear();
            }
        }
    }

    public class KisiIletisim
    {
        #region definations
        public int Id { get; set; }
        public string Adi { get; set; }
        public string Soyadi { get; set; }
        public int IletisimId { get; set; }
        public string GSM { get; set; }
        public string Eposta { get; set; }
        public string Adres { get; set; }
        public KisiIletisim()
        {

        }
        public KisiIletisim(int id, string adi,
            string soyadi, int iletisimId, string gsm,
            string eposta, string adres)
        {
            Id = id;
            Adi = adi;
            Soyadi = soyadi;
            IletisimId = iletisimId;
            Eposta = eposta;
            GSM = gsm;
            Adres = adres;
        }
        #endregion
    }
}
