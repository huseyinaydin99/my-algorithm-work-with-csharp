﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace AlgoritmaTasarimi.VTYS.Rehber
{
    public class Iletisim
    {
        public int Id { get; set; }
        public int KisiId { get; set; }
        public string GSM { get; set; }
        public string Eposta { get; set; }
        public string Adres { get; set; }
        public Iletisim()
        {

        }
        public Iletisim(int kisiId, 
            string gsm, 
            string eposta, 
            string adres)
        {
            KisiId = kisiId;
            GSM = gsm;
            Eposta = eposta;
            Adres = adres;
        }

        public Iletisim(int id,int kisiId, 
            string gsm,
            string eposta,
            string adres)
        {
            Id = id;
            KisiId = kisiId;
            GSM = gsm;
            Eposta = eposta;
            Adres = adres;
        }
        /// <summary>
        /// Iletisim ekleme yapar.
        /// </summary>
        /// <param name="i">Iletisim</param>
        /// <returns>true/false</returns>
        public bool Ekle(Iletisim i)
        {
            SqlCommand cmd = new SqlCommand("EXEC usp_Iletisim_Ekle @KisiId, @GSM, @Eposta, @Adres");
            cmd.Parameters.AddWithValue("KisiId", i.KisiId);
            cmd.Parameters.AddWithValue("GSM", i.GSM);
            cmd.Parameters.AddWithValue("Eposta", i.Eposta);
            cmd.Parameters.AddWithValue("Adres", i.Adres);
            bool s = VTYS.SqlExecuteNonQuery(cmd);
            if (s)
            {
                Kisi k = Kisi.Getir(i.KisiId);
                Console.WriteLine($"\n{k} iletisim bilgisi eklendi.\n");
            }       
            return s;
        }
        public bool Kaydet(Iletisim i)
        {
            SqlCommand cmd = 
                new SqlCommand("EXEC usp_Iletisim_Kaydet @KisiId,@GSM,@Eposta,@Adres");
            cmd.Parameters.AddWithValue("KisiId", i.KisiId);
            cmd.Parameters.AddWithValue("GSM", i.GSM);
            cmd.Parameters.AddWithValue("Eposta", i.Eposta);
            cmd.Parameters.AddWithValue("Adres", i.Adres);
            bool s = VTYS.SqlExecuteNonQuery(cmd);
            if(s)
            {
                Console.WriteLine("\nKaydetme başarılı!");
            }
            return s;
        }
        public static List<Iletisim> Listele()
        {
            try
            {
                List<Iletisim> list = new List<Iletisim>();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Iletisim");
                SqlDataReader reader = VTYS.SqlExecuteReader(cmd);
                while (reader.Read())
                {
                    list.Add(new Iletisim(Convert.ToInt32(reader["Id"]),
                        Convert.ToInt32(reader["KisiId"]),
                        reader["GSM"].ToString(),
                        reader["Eposta"].ToString(),
                        reader["Adres"].ToString()));
                }
                return list;
            }
            catch(Exception ex)
            {
                Console.WriteLine($"\a{ex.Message}");
                return new List<Iletisim>();
            }
        }

    }
}
