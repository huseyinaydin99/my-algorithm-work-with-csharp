﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace AlgoritmaTasarimi.VTYS.Rehber
{
    public class Kisi : IFormattable
    {
        #region Fields and Properties
        private int id;
        private string adi, soyadi;

        public int Id { get => id; set => id = value; }
        public string Adi { get => adi; set => adi = value; }
        public string Soyadi { get => soyadi; set => soyadi = value; }
        #endregion

        #region ToString()
        public override string ToString() => 
            $"\t{Adi} \t{Soyadi}";

        public string ToString(string format) => ToString(format, null);
        
        public string ToString(string format, IFormatProvider formatProvider)
        {
            switch (format)
            {
                case null:
                case "A":
                    return Adi;
                case "S":
                    return Soyadi;
                case "AS":
                    return $"{Adi}\t {Soyadi.ToUpper()}";
                case "I":
                    return Id.ToString();
                case "IAS":
                    return $"{Id}\t {Adi}\t {Soyadi}";
                default:
                    throw new FormatException($"Format {format} desteklenmiyor.");
            }
        }
        #endregion

        public Kisi()
        {

        }

        public Kisi(int id, string adi, string soyadi)
        {
            Id = id;
            Adi = adi;
            Soyadi = soyadi;
        }

        /// <summary>
        /// Kisi ekleme yapar
        /// </summary>
        /// <param name="k">Kisi sınıfından türemiş nesnedir</param>
        /// <returns>Başarılı olursa true aksi durumda false döner. </returns>
        public bool Ekle(Kisi k)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO Kisi(Adi, Soyadi) VALUES (@adi,@soyadi)");
            cmd.Parameters.AddWithValue("adi", k.Adi);
            cmd.Parameters.AddWithValue("soyadi", k.Soyadi);
            bool s = VTYS.SqlExecuteNonQuery(cmd);
            if (s)
                Console.WriteLine($"\n{k} eklendi.\n");
            return s;
        }

        /// <summary>
        /// Kisi tablosunda kayıtların bir listesini döner. 
        /// </summary>
        /// <returns></returns>
        public static List<Kisi> Listele()
        {
            List<Kisi> liste = new List<Kisi>();
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Kisi");
                SqlDataReader reader = VTYS.SqlExecuteReader(cmd);
                
                while (reader.Read())
                {
                    liste.Add(new Kisi(Convert.ToInt32(reader[0]), 
                        reader[1].ToString(), 
                        reader[2].ToString()));
                }
                return liste;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new List<Kisi>();
            }            
        }

        /// <summary>
        /// Kisi tablosundan kayıt siler. 
        /// </summary>
        /// <param name="id">Kisi.Id degeridir.</param>
        /// <returns>true/false</returns>
        public bool Sil(int id)
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM Kisi WHERE Id = @id");
            cmd.Parameters.AddWithValue("id", id);
            bool s = VTYS.SqlExecuteNonQuery(cmd);
            if (s)
                Console.WriteLine($"{id} numaralı kayıt silindi.");
            return s;
        }

        /// <summary>
        /// Kisi bilgisini getirir Id değerine bağlı olarak.
        /// </summary>
        /// <param name="id">Kisi.Id</param>
        /// <returns>Kisi</returns>
        public static Kisi Getir(int id)
        {
            Kisi k = new Kisi();
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Kisi WHERE Id = @id");
                cmd.Parameters.AddWithValue("id", id);
                SqlDataReader reader = VTYS.SqlExecuteReader(cmd);
                while (reader.Read())
                {
                    k.Id = Convert.ToInt32(reader[0]);
                    k.Adi = reader[1].ToString();
                    k.Soyadi = reader[2].ToString();
                }
                return k;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new Kisi();
            }
        }

        /// <summary>
        /// Kisi bilgisini gunceller.
        /// </summary>
        /// <param name="k">Kisi nesnesi</param>
        /// <returns>true/false</returns>
        public bool Guncelle(Kisi k)
        {
            SqlCommand cmd = new SqlCommand("UPDATE Kisi SET Adi = @adi, Soyadi=@Soyadi WHERE Id = @id");
            cmd.Parameters.AddWithValue("id", k.Id);
            cmd.Parameters.AddWithValue("adi", k.Adi);
            cmd.Parameters.AddWithValue("soyadi", k.Soyadi);
            bool s = VTYS.SqlExecuteNonQuery(cmd);
            if (s)
                Console.WriteLine($"{k} guncellendi.");
            return s;
        }

        /// <summary>
        /// Tüm Kisileri listeler.
        /// </summary>
        public static void TumunuListele()
        {
            List<Kisi> liste = Listele();
            Console.WriteLine("\n{0} KİŞİ LİSTESİ{0}\n",
                new string('-',25));
            Console.WriteLine("Id\t Adi \tSoyadi\n");
            foreach (Kisi item in liste)
                Console.WriteLine($"{item:IAS}");
            Console.WriteLine($"\n{liste.Count} kayit listelendi.");
            Console.WriteLine();
        }
        public static List<Kisi> Ara(string ifade)
        {
            List<Kisi> liste = new List<Kisi>();
            try
            {
                SqlCommand cmd = new SqlCommand("EXEC usp_Kisi_Ara @ifade");
                cmd.Parameters.AddWithValue("ifade", ifade);
                SqlDataReader reader = VTYS.SqlExecuteReader(cmd);

                while (reader.Read())
                {
                    liste.Add(new Kisi(Convert.ToInt32(reader[0]),
                        reader[1].ToString(),
                        reader[2].ToString()));
                }
                return liste;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new List<Kisi>();
            }
        }
        public static void AramaSonuclari(string ifade)
        {
            List<Kisi> liste = Ara(ifade);
            foreach (Kisi item in liste)
                Console.WriteLine($"{item.Id} {item}");
            Console.WriteLine($"\n{liste.Count} kayit bulundu.\n"); 
        }

        
    }
}