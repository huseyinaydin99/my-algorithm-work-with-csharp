﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgoritmaTasarimi.VTYS.Rehber
{
    public class Menu
    {
        public static void KisiMenu()
        {
            
            Console.WriteLine("{0} Kişi Menüsü {0}",
                new string('-',25));
            Console.WriteLine();
            Console.WriteLine("[1]\t Ekle");
            Console.WriteLine("[2]\t Listele");
            Console.WriteLine("[3]\t Ara");
            Console.WriteLine("[4]\t İletşim Bilgilerini Güncelle");
            Console.WriteLine("[5]\t Rehberim");
            Console.WriteLine("\n[1-5] seçiminiz?");
            try
            {
                int s = Convert.ToInt32(Console.ReadLine());
                KisiMenuSecim(s);
            }
            catch
            {
                Console.WriteLine("\a Geçersiz seçim!");
                Console.ReadKey();
                Console.Clear();
                KisiMenu();
            }
        }
        public static void KisiMenuSecim(int s)
        {
            switch (s)
            {
                case 1:
                    Kisi k = new Kisi();
                    Console.Clear();
                    Console.WriteLine("{0} KİŞİ EKLE {0}",
                        new string('-',25));
                    Console.WriteLine();

                    Console.Write("Kişi adi : ");
                    k.Adi = Console.ReadLine().Trim();
                    Console.Write("Kişi soyadi: ");
                    k.Soyadi = Console.ReadLine().Trim();
                    k.Ekle(k);
                    break;
                case 2:
                    Console.Clear();
                    Kisi.TumunuListele();
                    break;
                case 3:
                    Console.Clear();
                    Console.WriteLine("Aranacak kişi: ");
                    string ifade = Console.ReadLine();
                    Kisi.AramaSonuclari(ifade);
                    break;
                case 4:
                    Console.Clear();
                    Console.WriteLine("\n{0} İLETİŞİM BİLGİLERİNİ GÜNCELLE {0}",
                        new string('-',25));
                    Console.Write("\n Kisi Id değerini giriniz: ");
                    Iletisim i = new Iletisim();
                    i.KisiId = Convert.ToInt32(Console.ReadLine().Trim());
                    Console.Write("\n GSM :");
                    i.GSM = Console.ReadLine().Trim();
                    Console.Write("\n Eposta : ");
                    i.Eposta = Console.ReadLine().Trim();
                    Console.Write("\n Adres: ");
                    i.Adres = Console.ReadLine().Trim();
                    i.Kaydet(i);
                    Console.WriteLine("Devam etmek için bir tuşa basınız.");
                    Console.ReadKey();
                    break;
                case 5:
                    Console.Clear();
                    Rehberim.Listele();
                    RehberMenu();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("\a Geçersiz bir tercih yapıldı!");
                    break;
            }
            KisiMenu();
        }
        public static void RehberMenu()
        {
            Console.Write("\n[1] Kişi [2] Ara [3] Katolog Listele " +
                "[4] Illere Gore Dagilim [5] Çıkış \n");
            int secim = Convert.ToInt32(Console.ReadLine());
            switch (secim)
            {
                case 1:
                    KisiMenu();
                    break;
                case 2:
                    Console.Clear();
                    Console.Write("\n Aranacak ifade: ");
                    string ifade = Console.ReadLine();
                    Rehberim.Ara(ifade);
                    Console.WriteLine("\nDevam etmek icin bir tusa basiniz.\n");
                    Console.ReadKey();
                    Rehberim.Listele("artan");
                    Menu.RehberMenu();
                    break;
                case 3:
                    Console.Clear();
                    Rehberim.KatologYazdir();
                    Console.WriteLine("\nDevam etmek icin bir tusa basiniz.\n");
                    Console.ReadKey();
                    Rehberim.Listele("artan");
                    Menu.RehberMenu();
                    break;
                case 4:
                    Console.Clear();
                    Rehberim.IllereGoreKayitlar();
                    Console.WriteLine("\nDevam etmek icin bir tusa basiniz.\n");
                    Console.ReadKey();
                    Rehberim.Listele("artan");
                    Menu.RehberMenu();
                    break;
                case 5:
                    Environment.Exit(1);
                    break;
                default:
                    Console.WriteLine("Geçersiz seçim!");
                    break;
            }
        }
    }
}
