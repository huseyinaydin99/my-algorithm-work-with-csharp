﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace AlgoritmaTasarimi.VTYS.Rehber
{
    public class VTYS
    {
        private static string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Rehber;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        public static bool SqlExecuteNonQuery(SqlCommand cmd)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                cmd.Connection = conn;
                cmd.ExecuteNonQuery();
                
                conn.Close();
                cmd.Dispose();
                conn.Dispose();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\aHata! {ex.Message}");
                return false;
            }
        }
       
        public static SqlDataReader SqlExecuteReader(SqlCommand cmd)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            cmd.Connection = conn;
            return cmd.ExecuteReader();
        }


    }
}
