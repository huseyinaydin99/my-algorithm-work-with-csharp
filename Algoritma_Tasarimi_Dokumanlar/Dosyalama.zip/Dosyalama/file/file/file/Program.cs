﻿using System;
using System.Collections.Generic;
using System.Text;

namespace file
{
    class Program
    {
        static void Main(string[] args)
        {
            file01.AnaKod();
        }
    }
}
