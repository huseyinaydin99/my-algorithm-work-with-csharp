﻿using System;
using System.IO;

namespace file
{
    class file01
    {
        public static void AnaKod()
        {
			try
			{
				// dinamik konum
				string[] yol = Directory.GetCurrentDirectory().Split('\\');
				string dosyaYol = "";
				for (int i = 0; i < yol.Length - 3; i++)
					dosyaYol += yol[i] + '\\';
				dosyaYol += "Rakamlar.txt";

				// dosya okuma ve yazma
				using (StreamReader sr = new StreamReader(dosyaYol)) {
					string line;
					while ((line = sr.ReadLine())!=null)
					{
						Console.WriteLine(line);
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);				
			}
        }
    }
}
