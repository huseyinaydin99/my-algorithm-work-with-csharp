﻿using System;
using System.IO;

namespace file
{
    public static class file02
    {
        public static void AnaKod()
        {
			try
			{
				// dinamik yol tanimi 
				string[] yol = Directory.GetCurrentDirectory().Split('\\');
				string dosyaYol = "";
				for (int i = 0; i < yol.Length - 3; i++)
					dosyaYol += yol[i] + "\\";
				dosyaYol += "Adlar.txt";

				string[] adlar = new string[] { "Zara","Ayca","Mehmet","Selim","Kaan"};
				using (StreamWriter sw = new StreamWriter(dosyaYol))
				{
					foreach (string s in adlar)
						sw.WriteLine(s);
					Console.WriteLine("\n Adlar.txt dosyasi basarili bir sekilde olusturuldu");
				}
				
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}
        }
    }
}
