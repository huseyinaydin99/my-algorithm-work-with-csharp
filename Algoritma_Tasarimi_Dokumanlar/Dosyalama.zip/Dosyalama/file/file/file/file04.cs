﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace file
{
    public class file04
    {
        public static void AnaKod()
        {
            string dosyaYolu = Dosya.FizikselYol("Adlar.txt");
            var fi = new FileInfo(dosyaYolu);

            Console.WriteLine(fi.FullName);
            Console.WriteLine(fi.Length);
            Console.WriteLine(fi.Extension);
            Console.WriteLine(fi.CreationTime);
            Console.WriteLine(fi.LastAccessTime);
            Console.WriteLine(fi.Name);
        }
        
       
    }
}
