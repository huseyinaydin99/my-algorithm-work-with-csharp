﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace file
{
    public class Dosya
    {
        public static string FizikselYol(string dosyaAdi)
        {
            string[] yol = Directory.GetCurrentDirectory().Split('\\');
            string dosyaYol = "";
            for (int i = 0; i < yol.Length - 3; i++)
                dosyaYol += yol[i] + '\\';
            dosyaYol += dosyaAdi;
            return dosyaYol;
        }

        /// <summary>
        /// Dosya kopyalama islemi gerceklestirir.
        /// </summary>
        /// <param name="kaynak">Kaynak dosya yolu</param>
        /// <param name="hedef">Hedef dosya yolu</param>
        public static void Kopyalama(string kaynak,
            string hedef)
        {
            try
            {
                FileInfo fi = new FileInfo(kaynak);
                fi.CopyTo(hedef);
                Console.WriteLine("{0} kaynakli dosya {1} kopyalandi.",
                    kaynak, hedef);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Verilen parametre bilgisine bagli olarak ilgili dosyayi
        /// kalici olarak siler.
        /// </summary>
        /// <param name="kaynak">Kaynak dosya yolu.</param>
        public static void Silme(string kaynak)
        {
            try
            {
                FileInfo fi = new FileInfo(kaynak);
                fi.Delete();
            }
            catch (Exception e)
            {
                Console.WriteLine($"{e.Message}");
            }
        }
    }
}
