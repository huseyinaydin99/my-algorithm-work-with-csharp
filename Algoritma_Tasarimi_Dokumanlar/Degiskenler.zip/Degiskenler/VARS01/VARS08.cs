﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace VARS
{
    public static class VARS08
    {
        public static void AnaKod()
        {
            string[] meyveler = { "elma", "armut", "muz", "üzüm", "seftali" };
            var meyve = from m in meyveler
                        where m[0] == 'a'
                        select m;

            foreach (string m in meyve)
                Console.Write(m);
        }
    }
}
