﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VARS
{
    public static class VARS05
    {
        public static void AnaKod()
        {
            // static (Modifier) const ile beraber kullanılmaz!
            // static const int c = 23;

            // sabitler sabitlere katılabilir ;)


            // sabitlere olusturuldugu yerde degeri verilmelidir!
            // const int c1;
            // c1 = 3;

            const int c1 = 3;
            Console.WriteLine(c1);
        }
    }
}
