﻿using System;
using System.Linq;

namespace VARS
{
    class Program
    {
        enum programlar { iki,uc,bes,alti,sekiz }
        static void Main(string[] args)
        {
            switch (programlar.uc)
            {
                case programlar.iki:
                    VARS02.AnaKod();
                    break;
                case programlar.uc:
                    VARS03.AnaKod();
                    break;
                case programlar.bes:
                    VARS05.AnaKod();
                    break;
                case programlar.alti:
                    VARS06.AnaKod();
                    break;
                case programlar.sekiz:
                    VARS08.AnaKod();
                    break;
                default:
                    break;
            }
        }
    }

    
}
