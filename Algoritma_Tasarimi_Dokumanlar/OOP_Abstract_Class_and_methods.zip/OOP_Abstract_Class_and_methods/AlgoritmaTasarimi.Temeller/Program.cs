﻿using AlgoritmaTasarimi.Temeller.Cizim;
using System;
using System.Collections;
using System.Collections.Generic;
using Temeller = AlgoritmaTasarimi.Temeller;
namespace AlgoritmaTasarimi.Temeller
{
   
    class Program
    {
        public static void SekilCiz(Sekil sekil) 
            => sekil.Ciz();
        
        static void Main(string[] args)
        {
            Ucgen dikUcgen = new Ucgen();
            dikUcgen.Ciz();
            dikUcgen.YenidenBoyutlandir(50, 100);
            dikUcgen.Ciz();

            Sekil d = new Dikdortgen();
            d.Ciz();
        }
    }
}


