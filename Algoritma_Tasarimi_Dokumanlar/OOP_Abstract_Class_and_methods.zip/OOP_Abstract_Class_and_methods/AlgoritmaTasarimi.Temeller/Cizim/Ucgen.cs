﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgoritmaTasarimi.Temeller.Cizim
{
    public class Ucgen : Sekil
    {
        public override void YenidenBoyutlandir(int genislik, 
            int yukseklik)
        {
            Boyut.Genislik = genislik;
            Boyut.Yukseklik = yukseklik;
        }

        public override void Ciz()
        {
            Console.Write("Ucgen ");
            base.Ciz();
        }
    }
}
