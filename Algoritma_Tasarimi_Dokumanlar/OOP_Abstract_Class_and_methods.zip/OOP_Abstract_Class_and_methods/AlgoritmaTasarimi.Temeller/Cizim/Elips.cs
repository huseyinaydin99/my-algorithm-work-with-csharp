﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgoritmaTasarimi.Temeller.Cizim
{
    public class Elips : Sekil
    {
        public override void Tasi(Pozisyon yeniPozisyon)
        {
            Console.Write("Elips ");
            base.Tasi(yeniPozisyon);
            
        }

        public override void YenidenBoyutlandir(int genislik, 
            int yukseklik)
        {
            Boyut.Genislik = genislik;
            Boyut.Yukseklik = yukseklik;
        }

        
    }
}
