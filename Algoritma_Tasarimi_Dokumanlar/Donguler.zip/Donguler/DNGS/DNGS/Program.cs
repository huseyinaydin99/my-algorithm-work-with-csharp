﻿using System;

namespace DNGS
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
