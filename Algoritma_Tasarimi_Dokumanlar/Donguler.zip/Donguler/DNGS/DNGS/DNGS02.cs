﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DNGS
{
    public static class DNGS02
    {
        public static void Anakod()
        {
            // 1 den 100
            for (int i = 1; i <= 100; i ++)
            {
                Console.WriteLine("{0,5} -> {1,5}", i, i * i);
            }

            // 5 den 5 er arttirimlarla 100

            for (int i = 5; i <= 100; i += 5)
            {
                Console.WriteLine("{0,5} -> {1,5}", i, i * i);
            }

            // 100'den 5'e 5 er azaltimla... 
            for (int i = 100; i > 0; i -= 5)
            {
                Console.WriteLine("{0,5} -> {1,5}", i, i * i);
            }
        }
    }
}
