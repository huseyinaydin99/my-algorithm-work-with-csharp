﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IFEL
{
    public static class SWTC02
    {

        public enum Renkler { Kirmizi, Yesil, Mavi }
        public static void AnaKod()
        {
            Renkler r = (Renkler)(new Random()).Next(0, 10);

            switch (r)
            {
                case Renkler.Kirmizi:
                    Console.WriteLine("Renk kirmizidir.");
                    break;
                case Renkler.Yesil:
                    Console.WriteLine("Renk yesildir.");
                    break;
                case Renkler.Mavi:
                    Console.WriteLine("Renk mavidir.");
                    break;
                default:
                    Console.WriteLine("Renk bilinmiyor.");
                    break;
            }
        }
    }
}
