﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IFEL
{
    public static class IFEL03
    {
        /// <summary>
        /// IF ELSE bloklarının AND ve OR yapısıyla kullanımı.
        /// </summary>
        public static void AnaKod()
        {
            int m = 9;
            int n = 7;
            int p = 5;


            if (m >= n && m >= p)
            {
                Console.WriteLine("En buyuk m");
            }

            if (m > n && !(p > m))
            {
                Console.WriteLine("En buyuk m");
            }

            if (m > n || m > p)
            {
                Console.WriteLine("m en kucuk degil!");
            }

            m = 4;
            if (!(m >= n || m >= p))
            {
                Console.WriteLine("m artik en kucuk!");
            }
        }
    }
}
