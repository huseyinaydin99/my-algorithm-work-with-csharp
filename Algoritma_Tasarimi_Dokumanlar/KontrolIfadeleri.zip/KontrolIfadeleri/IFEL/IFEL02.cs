﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IFEL
{
    public static class IFEL02
    {
        /// <summary>
        /// IFEL-02	if-else Uygulaması
        /// Girilen karakterin kontrol edildigi program.
        /// </summary>
        public static void AnaKod()
        {
            Console.WriteLine("Bir karakter giriniz: ");
            char ch = (char)Console.Read();

            if (Char.IsUpper(ch))
            {
                Console.WriteLine("Girilen karakter büyük bir karaterdir.");
            }
            else if (Char.IsLower(ch))
            {
                Console.WriteLine("Girilen karakter kucuk bir karakterdir.");
            }
            else if (Char.IsDigit(ch))
            {
                Console.WriteLine("Karakter bir rakamdır.");
            }
            else
            {
                Console.WriteLine("Karakter alfanumerik bir ifade degildir.");
            }
        }
    }
}
