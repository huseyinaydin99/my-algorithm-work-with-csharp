﻿using System;

namespace CBDZ
{
    class Program
    {
        static void Main(string[] args)
        {
           
           
        }
    }
}
