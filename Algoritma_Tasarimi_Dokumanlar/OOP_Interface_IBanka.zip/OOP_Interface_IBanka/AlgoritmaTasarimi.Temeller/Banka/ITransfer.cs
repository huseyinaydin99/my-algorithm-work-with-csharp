﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgoritmaTasarimi.Temeller.Banka
{
    public interface ITransfer : IBankaHesap
    {
        bool TransferYap(IBankaHesap aliciHesap,
            decimal miktar);
    }
}
