﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Katarlar
{
    public static class STRG03
    {
        public static void AnaKod()
        {
            // ifadenin okunmasi
            string ifade = Console.ReadLine();
            // sesli harf sayinin belirlenmesi
            int sesliHarfSayisi = 0;
            // sesli harf sayisinin tespiti icin dongunun kurulmasi
            for (int i = 0; i < ifade.Length; i++)
            {
                // gerekli kontrolün yapılmasi
                if (ifade[i] == 'a' || ifade[i] == 'A' ||
                    ifade[i] == 'e' || ifade[i] == 'E' ||
                    ifade[i] == 'ı' || ifade[i] == 'I' ||
                    ifade[i] == 'i' || ifade[i] == 'İ' ||
                    ifade[i] == 'u' || ifade[i] == 'U' ||
                    ifade[i] == 'ü' || ifade[i] == 'Ü' ||
                    ifade[i] == 'o' || ifade[i] == 'O' ||
                    ifade[i] == 'ö' || ifade[i] == 'Ö')
                        sesliHarfSayisi++;
                
            }
            Console.WriteLine("\"{0}\" ifadesinde {1} adet sesli harf tespit edildi.",
                ifade,sesliHarfSayisi);
        }
    }
}
