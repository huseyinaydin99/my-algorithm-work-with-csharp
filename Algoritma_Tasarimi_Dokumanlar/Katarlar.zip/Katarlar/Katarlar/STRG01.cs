﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Katarlar
{
    public static class STRG01
    {
        public static void AnaKod()
        {
            // konsoldan girilen değerin okunması 
            string ifade = Console.ReadLine();

            // ifadenin , karakterine bağlı olarak ayrıştırılması 
            string[] bolunmusIfade = ifade.Split(',');
            // döngü ve sayısal dizi için dizi uzunluğunun tespit edilmesi
            int n = bolunmusIfade.Length;
            // sayısal dizinin deklare edilmesi 
            int[] sayisalDizi = new int[n];
            // ayrıştırma için döngü tasarımı
            for (int i = 0; i < n; i++)
            {
                sayisalDizi[i] = Convert.ToInt32(bolunmusIfade[i]);
                Console.WriteLine("dizi[{0}] = {1}", i + 1, sayisalDizi[i]);
            }
        }
    }
}
