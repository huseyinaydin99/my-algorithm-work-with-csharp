﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Katarlar
{
    public static class STRG04
    {
        public static void AnaKod()
        {
            // ifadenin okunmasi
            string ifade = Console.ReadLine();
            
        }
    }
}
