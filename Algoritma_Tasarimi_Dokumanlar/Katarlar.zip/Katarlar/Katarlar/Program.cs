﻿using System;

namespace Katarlar
{
    class Program
    {
        static void Main(string[] args)
        {
            STRG03.AnaKod();        
        }
    }
}
