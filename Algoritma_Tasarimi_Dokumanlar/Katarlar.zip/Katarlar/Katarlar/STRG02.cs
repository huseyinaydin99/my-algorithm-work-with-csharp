﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Katarlar
{
    public static class STRG02
    {
        public static void AnaKod()
        {
            // ikilik sayinin okunmasi
            string ikilikSayi = Console.ReadLine();
            // uzunlugunun belirlenmesi 
            int n = ikilikSayi.Length;

            // herbir basamagin bir dizide tutulmasi
            int[] basamaklar = new int[n];
            // onluk sayi sisteminde karsiligi icin degikenin tanimlanmasi 
            int sayi = 0;
            // kontrol ifadesinin tanimlanmasi 
            bool kontrol = true;
            // herbir basamak degerinin bir diziye aktarilmasi ve 0 - 1'lerin kontrolü
            for (int i = 0; i < n; i++)
            {
                if (!(ikilikSayi[i] == '0' || ikilikSayi[i] == '1'))
                {
                    Console.WriteLine("\aHatali Giris!");
                    kontrol = false;
                    break;
                }
                basamaklar[i] = (int)(ikilikSayi[i] - '0');
            }


            if (kontrol)
            {
                for (int i = 0; i < n; i++)
                    sayi += (int)Math.Pow(2, n - 1 - i) * basamaklar[i];
                Console.WriteLine("({0}) ikilik sayi = {1}", ikilikSayi, sayi);
            }
        }
    }
}
