﻿using System;

namespace TMD1
{
    class Program
    {
        static void Main(string[] args)
        {
            double r = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Alan = {0:F2}", 
                Daire.AlaniHesapla(r,60));
        }
    }
}
