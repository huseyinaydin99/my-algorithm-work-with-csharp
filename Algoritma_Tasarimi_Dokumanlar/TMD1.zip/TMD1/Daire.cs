﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TMD1
{
    public class Daire
    {
        public const double pi = 3.14;
        /// <summary>
        /// Dairenin alanin hesaplar
        /// </summary>
        /// <param name="r">Yaricap</param>
        /// <returns>Alan değeridir</returns>
        public static double AlaniHesapla(double r)
        {
            return pi * r * r;
        }

        /// <summary>
        /// Dairenin alani hesaplar.
        /// </summary>
        /// <param name="r">Yaricap</param>
        /// <param name="aci">Gördüğü açı</param>
        /// <returns>Alan değeri.</returns>
        public static double AlaniHesapla(double r, double aci)
        {
            return pi * r * r * aci/360;
        }
    }
}
