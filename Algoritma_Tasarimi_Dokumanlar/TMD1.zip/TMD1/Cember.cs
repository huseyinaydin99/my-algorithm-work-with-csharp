﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TMD1
{
    public class Cember
    {
        public const double pi = 3.14;

        /// <summary>
        /// Çemberin çevresi hesaplar.
        /// </summary>
        /// <param name="r">Yarı çap</param>
        /// <returns>Çemberin çevresi</returns>
        public static double Cevresi(double r)
        {
            return 2 * pi * r;
        }
    }
}
