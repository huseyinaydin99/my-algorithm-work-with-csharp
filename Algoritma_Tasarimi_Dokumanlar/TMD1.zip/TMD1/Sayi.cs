﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TMD1
{
    public class Sayi
    {
        /// <summary>
        /// Parametre olarak aldigi sayinin tek mi yoksa cift oldugunu kontrol eder.
        /// </summary>
        /// <param name="n">Sayi</param>
        /// <returns>Tek ise true aksi durumda false dönüş yapar. </returns>
        public static bool TekMi(int n)
        {
            if (n % 2 == 1)
                return true;
            return false;
        }
        /// <summary>
        /// Parametere olarak aldigi sayinin cift olup olmadigini kontrol eder.
        /// </summary>
        /// <param name="n">Girilen sayi</param>
        /// <returns>n degeri Cift ise true aksi durumda false degerini doner</returns>
        public static bool CiftMi(int n)
        {
            if (n % 2 == 0)
                return true;
            return false;
        }

        /// <summary>
        /// Parametere olarak aldigi sayinin mutlak degerini doner.
        /// </summary>
        /// <param name="n">Girilen sayiyi temsil eder.</param>
        /// <returns>Girilen sayinin mutlak degeri dönüş ifadesidir.</returns>
        public static int MutlakDeger(int n)
        {
            if (n > 0)
                return n;
            else if (n < 0)
                return -1 * n;
            else
                return 0;
        }

        /// <summary>
        /// Parametere olarak aldigi sayinin asal sayi olup olmadigini kontrol eder.
        /// </summary>
        /// <param name="n">Sayi</param>
        /// <returns>Parametere asal ise true; aksi durumda false döner. </returns>
        public static bool AsalMi(int n)
        {
            if (n <= 1)
            {
                Console.WriteLine("En kucuk asal sayi 2'dir.");
                return false;
            }

            bool kontrol = true;
            for (int i = 2; i < n; i++)
                if (n % i == 0)
                {
                    kontrol = false;
                    break;
                }
            return kontrol;
        }
        
        /// <summary>
        /// Parametere olarak aldigi sayinin rakamlari toplamini doner
        /// </summary>
        /// <param name="n">Sayi</param>
        /// <returns>Rakamlarin toplamidir.</returns>
        public static int RakamlariToplami(int n)
        {
            int toplam = 0, rakam = 0;
            while (n>0)
            {
                rakam = n % 10;
                toplam += rakam;
                n = n / 10;
            }
            return toplam;
        }

        /// <summary>
        ///  Bir döngü yardımıyla birden N'e kadar olan sayilarin toplamini hesaplar.
        /// </summary>
        /// <param name="n">n sayisini temsil eder.</param>
        /// <returns>Toplam sonucunu döner</returns>
   
        public static int NeKadarOlanSayilarinToplami(int n)
        {
            int t = 0;
            for (int i = 1; i <= n; i++)
                t += i;
            return t;
        }

        /// <summary>
        /// Bir formül yardımıyla birden N'e kadar olan sayilarin toplamini hesaplar.
        /// </summary>
        /// <param name="n">n sayısını temsil eder</param>
        /// <returns>Toplam sonucu dönülür.</returns>
        public static int NeKadarOlanSayilarinFormulleToplami(int n)
        {
            return n*(n+1)/2;
        }

        /// <summary>
        /// Birden N'e kadar olan tek sayilarin toplamı
        /// </summary>
        /// <param name="n">N sayisi</param>
        /// <returns>Toplam sonucu</returns>
        public static int NeKadarOlanTekSayilarinToplami(int n)
        {
            int t = 0;
            for (int i = 1; i <= n; i++)
            {
                if (i % 2 == 1)
                    t += i;
            }
            return t;
        }

        /// <summary>
        /// Birden N'e kadar olan sayilarin toplami, alternatif çözüm
        /// </summary>
        /// <param name="n">N sayisi</param>
        /// <returns>Toplam sonucu</returns>
        public static int NeKadarOlanTekSayilarinToplamiAlternatifCozum(int n)
        {
            int t = 0;
            for (int i = 1; i <= n; i += 2)
                t += i;
            return t;
        }

        /// <summary>
        /// Birden N'e kadar olan sayilarin toplami, formülle çözüm. 
        /// </summary>
        /// <param name="n">N sayisi</param>
        /// <returns>Toplam sonucu</returns>
        public static int NeKadarOlanTekSayilarinFormulleToplami(int n)
        {
            n = n + 1;
            n = n / 2;
            return n * n;
        }

        /// <summary>
        /// 2'den N'e kadar olan sayilarin toplami
        /// </summary>
        /// <param name="n">N sayisi</param>
        /// <returns>Toplam sonucu</returns>
        public static int NeKadarOlanCiftSayilarinToplami(int n)
        {
            int t = 0;
            for (int i = 2; i <= n; i++)
            {
                if (i % 2 == 0)
                    t += i;
            }
            return t;

        }

        /// <summary>
        ///  2'den N'e kadar olan sayilarin toplami, alternatif çözüm
        /// </summary>
        /// <param name="n">N sayisi</param>
        /// <returns>Toplam sonucu</returns>
        public static int NeKadarOlanCiftSayilarinToplamiAlternatifCozum(int n)
        {
            int t = 0;
            for (int i = 2; i <= n; i += 2)
                t += i;
            return t;
        }

        /// <summary>
        /// 2'den N'e kadar olan sayilarin toplami, formülle çözüm
        /// </summary>
        /// <param name="n">N sayisi</param>
        /// <returns>Toplam sonucu</returns>
        public static int NeKadarOlanCiftSayilarinFormulleToplami(int n)
        {
            n = n / 2;
            return n * (n + 1);
        }


    }
}
